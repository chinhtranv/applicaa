﻿namespace SIMSBulkImport
{
    /// <summary>
    ///     Interaction logic for Duplicate.xaml
    /// </summary>
    public partial class Duplicate
    {
        public Duplicate()
        {
            InitializeComponent();
        }
    }
}