﻿namespace SIMSBulkImport
{
    public interface ISwitchable
    {
        void UtilizeState(object state);
    }
}