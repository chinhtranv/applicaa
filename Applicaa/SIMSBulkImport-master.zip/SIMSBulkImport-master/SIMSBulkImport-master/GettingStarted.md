# Getting Started

[SIMS Bulk Import](https://simsbulkimport.uk) uses the Capita SIMS Business Objects, this requires the SIMS .net client to be installed. Please ensure you have SIMS .net installed and working before installing [SIMS Bulk Import](https://simsbulkimport.uk).

[SIMS Bulk Import](https://simsbulkimport.uk) is designed to be used by the end-user, it is recommended that it is installed on the end-users workstation.

You must have permissions within SIMS .net to write data to the relevant fields to be able to import data using [SIMS Bulk Import](https://simsbulkimport.uk).

You can [download the latest release from here](https://github.com/SIMSBulkImport/SIMSBulkImport/releases/latest).
