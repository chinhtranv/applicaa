# Developing SIMS Bulk Import

You must have
- [Visual Studio 2015](https://go.microsoft.com/fwlink/?LinkId=691978&clcid=0x409)
- [Office Developer Tools for Visual Studio 2015](https://www.visualstudio.com/en-us/features/office-tools-vs.aspx)
- [WIX Toolset](http://wixtoolset.org/releases/)
- SIMS .net client

You will need to set the SIMSDOTNETDIRECTORY Environment variable to the SIMS .net client installation directory, this is normally c:\program files (x86)\sims\sims .net\.
You can run the follow PowerShell script to set this - https://gist.github.com/matt40k/eccba084aa10c15f66f9
