﻿using System;

namespace SIMSBulkImport
{
    public class Interfaces
    {
        public enum UserType
        {
            Pupil,
            Staff,
            Contact,
            Unknown
        };
    }
}
