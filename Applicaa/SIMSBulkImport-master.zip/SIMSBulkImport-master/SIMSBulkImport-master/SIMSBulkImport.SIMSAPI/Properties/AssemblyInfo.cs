﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SIMS API")]
[assembly: AssemblyDescription("SIMS Bulk Import library for interfacing with SIMS .net")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SIMSBulkImport.uk")]
[assembly: AssemblyProduct("SIMS API")]
[assembly: AssemblyCopyright("Copyright © SIMSBulkImport.uk 2011 - 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]