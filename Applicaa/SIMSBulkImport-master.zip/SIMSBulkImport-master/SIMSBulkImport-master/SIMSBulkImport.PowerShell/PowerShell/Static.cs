﻿namespace SIMSBulkImport.PowerShell
{
    internal static class Core
    {
        internal static SIMSBulkImport.SIMSAPI SimsApi;
    }
}
